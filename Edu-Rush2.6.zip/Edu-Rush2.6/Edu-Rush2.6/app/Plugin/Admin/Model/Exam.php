<?php
class Exam extends AppModel
{
  public $actsAs = array('search-master.Searchable');
  public $filterArgs = array('keyword' => array('type' => 'like','field'=>'Exam.name'));
  public function UserWiseGroup($userGroupWiseId)
  {
    $Exam=ClassRegistry::init('Exam');
    $Exam->bindModel(array('hasAndBelongsToMany'=>array('Group'=>array('className'=>'Group',
                                                     'joinTable' => 'exam_groups',
                                                     'foreignKey' => 'exam_id',
                                                     'associationForeignKey' => 'group_id',
                                                     'conditions'=>"ExamGroup.group_id IN($userGroupWiseId)"))));
  }
  public function examStats($id)
  {
    $Exam=ClassRegistry::init('Exam');
    $examvalue=$Exam->find('first',array('fields'=>array('id','name','start_date','end_date','passing_percent'),
                                      'joins'=>array(array('table'=>'exam_groups','type'=>'INNER','alias'=>'ExamGroup','conditions'=>array('Exam.id=ExamGroup.exam_id'))),
                         'conditions'=>array('Exam.status'=>'Closed','Exam.id'=>$id)
                         ));
    $examStats=array();
    $examStats['Exam']['id']=$examvalue['Exam']['id'];
    $examStats['Exam']['name']=$examvalue['Exam']['name'];
    $examStats['Exam']['start_date']=$examvalue['Exam']['start_date'];
    $examStats['Exam']['end_date']=$examvalue['Exam']['end_date'];
    $examStats['OverallResult']['passing']=(float) $examvalue['Exam']['passing_percent'];
    $examStats['OverallResult']['average']=(float) $this->studentAverageResult($examvalue['Exam']['id']);
    $examStats['StudentStat']['pass']=$this->studentStat($examvalue['Exam']['id'],'Pass');
    $examStats['StudentStat']['fail']=$this->studentStat($examvalue['Exam']['id'],'Fail');
    $examStats['StudentStat']['absent']=(float) $this->examTotalAbsent($examvalue['Exam']['id']);
    return$examStats;
  }
  public function examAttendance($id,$type)
  {
    $examStats=array();
    $examStats=$this->studentStat($id,$type,'all');
    return$examStats;
  }
  public function examAbsent($id)
  {
    $examStats=array();
    $examStats=$this->examTotalAbsent($id,'all');
    return$examStats;
  }
}
?>