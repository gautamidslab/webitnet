<?php
class Question extends AppModel
{
  public $actsAs = array('search-master.Searchable');
  public $belongsTo=array('Subject','Qtype','Diff');
  public $filterArgs = array('keyword' => array('type' => 'like','field'=>'Question.question'));
  public function UserWiseGroup($userGroupWiseId)
  {
    $Question=ClassRegistry::init('Question');
    $Question->bindModel(array('hasAndBelongsToMany'=>array('Group'=>array('className'=>'Group',
                                                     'joinTable' => 'question_groups',
                                                     'foreignKey' => 'question_id',
                                                     'associationForeignKey' => 'group_id',
                                                     'conditions'=>"QuestionGroup.group_id IN($userGroupWiseId)"))));
  }
}
?>