<?php
class Group extends AppModel
{
  public $actsAs = array('search-master.Searchable');
  public $filterArgs = array('keyword' => array('type' => 'like','field'=>'Group.group_name'));
  public $validate = array('group_name' => array('alphaNumeric' => array('rule' => '/^[a-z0-9 +.-]*$/i','required' => true,'message' => 'Only letters and numbers allowed'),
                                                 'isUnique'=>array('rule' => 'isUnique','message' => 'This Group has already been taken.'))
                            );
}
?>