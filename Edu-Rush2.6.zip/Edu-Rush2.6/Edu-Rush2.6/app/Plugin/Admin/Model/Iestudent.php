<?php
class Iestudent extends AppModel
{
  public $name = 'Iestudent';
  public $useTable = 'students';
  public $primaryKey = 'id';  
  public $actsAs=array('Utils.CsvImport');
  public function UserWiseGroup($userGroupWiseId)
  {
    $Iestudent=ClassRegistry::init('Iestudent');
    $Iestudent->bindModel(array('hasAndBelongsToMany'=>array('Group'=>array('className'=>'Group',
                                                     'joinTable' => 'student_groups',
                                                     'foreignKey' => 'student_id',
                                                     'associationForeignKey' => 'group_id',
                                                     'conditions'=>"StudentGroup.group_id IN($userGroupWiseId)"))));
  }
}
?>