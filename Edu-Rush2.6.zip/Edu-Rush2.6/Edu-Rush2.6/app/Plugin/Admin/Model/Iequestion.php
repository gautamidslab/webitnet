<?php
class Iequestion extends AppModel
{
  public $name = 'Iequestion';
  public $useTable = 'questions';
  public $primaryKey = 'id';
  public $belongsTo=array('Subject','Qtype','Diff');
  public $actsAs=array('Utils.CsvImport');
  public function UserWiseGroup($userGroupWiseId)
  {
    $Iequestion=ClassRegistry::init('Iequestion');
    $Iequestion->bindModel(array('hasAndBelongsToMany'=>array('Group'=>array('className'=>'Group',
                                                     'joinTable' => 'question_groups',
                                                     'foreignKey' => 'question_id',
                                                     'associationForeignKey' => 'group_id',
                                                     'conditions'=>"QuestionGroup.group_id IN($userGroupWiseId)"))));
  }
}
?>