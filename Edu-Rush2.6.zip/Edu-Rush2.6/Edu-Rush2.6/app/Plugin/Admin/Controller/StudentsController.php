<?php
App::uses('CakeTime', 'Utility');
App::uses('SimplePasswordHasher', 'Controller/Component/Auth');
App::uses('CakeEmail', 'Network/Email');
class StudentsController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator');
    public $components = array('Session','Paginator','search-master.Prg','CustomFunction');
    public $presetVars = true;
    var $paginate = array('joins'=>array(
                                         array('table'=>'student_groups','type'=>'INNER','alias'=>'StudentGroup','conditions'=>array('Student.id=StudentGroup.student_id')),
                                         array('table'=>'user_groups','type'=>'INNER','alias'=>'UserGroup','conditions'=>array('StudentGroup.group_id=UserGroup.group_id'))),
                          'limit'=>20,'maxLimit'=>500,'page'=>1,'order'=>array('Student.id'=>'desc'),'group'=>array('Student.id'));
    var $paginate1 = array('limit'=>20,'maxLimit'=>500,'page'=>1,'order'=>array('Wallet.id'=>'desc'));
    public function beforeFilter()
    {
        parent::beforeFilter();
        $this->currentDateTime=CakeTime::format('Y-m-d H:i:s',CakeTime::convert(time(),$this->siteTimezone));
        $this->currentDate=CakeTime::format('Y-m-d',CakeTime::convert(time(),$this->siteTimezone));
        $this->adminId=$this->adminValue['User']['id'];        
    }
    public function index()
    {
        $this->Student->UserWiseGroup($this->userGroupWiseId);
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate;
        $cond="";
        $cond=" 1=1 AND `UserGroup`.`user_id`=$this->luserId ";
        $this->Paginator->settings['conditions'] = array($this->Student->parseCriteria($this->Prg->parsedParams()),$cond);
        $this->set('Student', $this->Paginator->paginate());
        $this->set('frontExamPaid',$this->frontExamPaid);
    }    
    public function add()
    {
        $this->loadModel('Group');
        $this->set('group_id', $this->Group->find('list',array('fields'=>array('id','group_name'),'conditions'=>array("Group.id IN($this->userGroupWiseId)"))));
        if ($this->request->is('post'))
        {
            try
            {
                $passwordHasher = new SimplePasswordHasher(array('hashType' => 'sha256'));
                $password = $this->request->data['Student']['password'];
                $this->request->data['Student']['password'] = $passwordHasher->hash($password);
                $this->request->data['Student']['reg_status'] = "Done";
                $this->request->data['Student']['renewal_date'] = $this->currentDate;
                if(is_array($this->request->data['StudentGroup']['group_name']))
                {
                    if ($this->Student->save($this->request->data))
                    {
                        $this->loadModel('StudentGroup');
                        $this->request->data['StudentGroup']['student_id'] = $this->Student->id;
                        if(is_array($this->request->data['StudentGroup']['group_name']))
                        {
                            foreach($this->request->data['StudentGroup']['group_name'] as $key => $value)
                            {
                                $this->StudentGroup->create();
                                $this->request->data['StudentGroup']['group_id']=$value;
                                $this->StudentGroup->save($this->request->data);                        
                            }
                        }
                        if($this->emailNotification==1)
                        {
                            $email=$this->request->data['Student']['email'];$studentName=$this->request->data['Student']['name'];
                            $emailMessage="Dear ".$studentName.",<br><br>Congratulations! Your ".$this->siteName." account is now active.
                            <br><br>Email Address (Username): ".$email."<br><br>Password: ".$password."<br><br>If you need, you can reset your password at any time.<br><br>
                            To get started, log on:<a target=\"_blank\" href=\"".$this->siteDomain."\">".$this->siteDomain."</a><br><br>
                            If you have any questions or need assistance, please contact us.<br><br>Best Regards,<br>".$this->siteName." Support Team<br>
                            ".$this->siteEmail."<br>".$this->siteEmailContact;
                            if($email)
                            {
                                $toEmail=array($email=>$studentName);
                                $Email = new CakeEmail();
                                $Email->from(array($this->siteEmail =>$this->siteName));
                                $Email->to($toEmail);
                                $Email->emailFormat('html');
                                $Email->subject($this->siteName.' candidate login credentials');
                                $Email->send($emailMessage);
                            }
                        }
                        if($this->smsNotification==1)
                        {
                            $mobileNo=$this->request->data['Student']['phone'];
                            $smsMessage="Dear $studentName, Thanks for joining. Email: $email Password: $password Url: $this->siteDomain";
                            $this->Student->sendSms($mobileNo,$smsMessage);
                        }
                        $this->Session->setFlash('Your Student has been saved.','flash',array('alert'=>'success'));
                        return $this->redirect(array('action' => 'add'));
                    }
                }
                else
                {
                    $this->Session->setFlash('Please Select atleast one group','flash',array('alert'=>'danger'));
                    $this->request->data['Student']['password']=$password;
                }
            }
            catch (Exception $e)
            {
                $this->Session->setFlash('Student Email already exist.','flash',array('alert'=>'danger'));
                $this->request->data['Student']['password']=$password;
            }
        }
    }
    public function edit($id = null)
    {
        $this->layout = null;
        $this->Student->UserWiseGroup($this->userGroupWiseId);
        $this->loadModel('Group');
        $this->set('group_id', $this->Group->find('list',array('fields'=>array('id','group_name'),'conditions'=>array("Group.id IN($this->userGroupWiseId)"))));
        if (!$id)
        {
            throw new NotFoundException(__('Invalid post'));
        }
        $ids=explode(",",$id);
        $post=array();
        $group_select=array();
        foreach($ids as $id)
        {
            $this->Student->UserWiseGroup($this->userGroupWiseId);
            $post[]=$this->Student->findByid($id);            
        }
        $this->set('Student',$post);
        if (!$post)
        {
            throw new NotFoundException(__('Invalid post'));
        }
        if ($this->request->is(array('post', 'put')))
        {
            $this->Student->id = $id;
            try
            {
                foreach($this->data['Student'] as $key => $value)
                {
                    if($this->request->data['Student'][$key]['status']=="Active")
                    {
                        $this->request->data['Student'][$key]['reg_status']="Done";
                        $this->request->data['Student'][$key]['reg_code']="";
                    }
                    if(!is_array($this->request->data['StudentGroup'][$key]['group_name']))
                    {
                        $this->Session->setFlash('Please Select any group','flash',array('alert'=>'danger'));
                        return $this->redirect(array('action' => 'index'));
                    }
                    else
                    {
                        if ($this->Student->save($this->request->data['Student'][$key]))
                        {
                            if(is_array($this->request->data['StudentGroup'][$key]['group_name']))
                            {
                                $this->loadModel('StudentGroup');
                                $this->StudentGroup->deleteAll(array('StudentGroup.student_id'=>$key,"StudentGroup.group_id IN($this->userGroupWiseId)"));
                                foreach($this->request->data['StudentGroup'][$key]['group_name'] as $key1 => $value1)
                                {
                                    $this->StudentGroup->create();
                                    $this->request->data['StudentGroup'][$key1]['student_id']=$key;
                                    $this->request->data['StudentGroup'][$key1]['group_id']=$value1;                            
                                    $this->StudentGroup->save($this->request->data['StudentGroup'][$key1]);
                                }
                            }
                            $this->Session->setFlash('Your Student has been updated.','flash',array('alert'=>'success'));                        
                        }
                    }
                }                
                return $this->redirect(array('action' => 'index'));
            }
            catch (Exception $e)
            {
                $this->Session->setFlash('Student Email already exist.','flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
        }
        if (!$this->request->data)
        {
            $this->request->data = $post;
        }
    }    
    public function deleteall()
    {
        if ($this->request->is('post'))
        {
            $this->loadModel('StudentGroup');
            foreach($this->data['Student']['id'] as $key => $value)
            {
                $this->StudentGroup->deleteAll(array('StudentGroup.student_id'=>$value,"StudentGroup.group_id IN($this->userGroupWiseId)"));
            }
            $this->Student->query("DELETE `Student` FROM `students` AS `Student` LEFT JOIN `student_groups` AS `StudentGroup` ON `Student`.`id` = `StudentGroup`.`student_id` WHERE `StudentGroup`.`id` IS NULL");
            $this->Session->setFlash('Your Student has been deleted.','flash',array('alert'=>'success'));
        }        
        $this->redirect(array('action' => 'index'));
    }
    public function view($id = null)
    {
        $this->layout = null;
        if (!$id)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        $this->Student->bindModel(array('hasAndBelongsToMany'=>array('Group'=>array('className'=>'Group',
                                                     'joinTable' => 'student_groups',
                                                     'foreignKey' => 'student_id',
                                                     'associationForeignKey' => 'group_id',
                                                     'conditions'=>"StudentGroup.group_id IN($this->userGroupWiseId)"))));
        $post = $this->Student->findById($id);
        if (!$post)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        if(strlen($post['Student']['photo'])>0)
        $std_img='student_thumb/'.$post['Student']['photo'];
        else
        $std_img='User.png';
        $this->set('post', $post);
        $this->set('std_img', $std_img);
        $this->set('id', $id);
    }
    public function changePass($id = null)
    {
        $this->layout = null;
        if (!$id)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        $post = $this->Student->findById($id);
        if (!$post)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        if ($this->request->is(array('post', 'put')))
        {
            $passwordHasher = new SimplePasswordHasher(array('hashType' => 'sha256'));
            $this->Student->id = $id;
            $this->request->data['Student']['password'] = $passwordHasher->hash($this->request->data['Student']['password']);
            if ($this->Student->save($this->request->data))
            {
                $this->Session->setFlash('Password Changed Successfully','flash',array('alert'=>'success'));
                $this->redirect(array('action' => 'index'));
            }
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        if (!$this->request->data)
        {
            $this->request->data = $post;
        }
    }
    public function changePhoto($id = null)
    {
        $this->layout = null;
        if (!$id)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        $post = $this->Student->findById($id);
        if (!$post)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        if ($this->request->is(array('post', 'put')))
        {
            $this->Student->id = $id;
            if ($this->Student->save($this->request->data))
            {
                $this->Session->setFlash('Photo Changed Successfully','flash',array('alert'=>'success'));
                $this->redirect(array('action' => 'index'));
            }
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        if (!$this->request->data)
        {
            $this->request->data = $post;
        }
    }
    public function wallet($id = null)
    {
        $this->layout = null;
        $this->loadModel('Wallet');
        $ids=explode(",",$id);
        $post=array();
        foreach($ids as $id)
        {
            $post[]=$this->Student->find('first',array('joins' =>array(array('table'=>'wallets','alias'=>'Wallet','type'=>'Left','conditions'=>array('Student.id=Wallet.student_id'))),
                                                     'conditions'=>array('Student.id'=>$id),
                                                     'fields'=>array("id","email","name","phone","Wallet.balance"),
                                                     'order'=>array('Student.id ASC','Wallet.id DESC')));   
        }
        $this->set('Student',$post);
        if (!$post)
        {
            throw new NotFoundException(__('Invalid post'));
        }
        if ($this->request->is(array('post', 'put')))
        {
            $this->Student->id = $id;
            try
            {
                foreach($this->data['Student'] as $key => $value)
                {
                    if($this->CustomFunction->WalletInsert($this->request->data['Student'][$key]['id'],$this->request->data['Student'][$key]['amount'],$this->request->data['Student'][$key]['action'],$this->currentDateTime,"AD",$this->request->data['Student'][$key]['remarks'],$this->adminId))
                    {
                        $this->Session->setFlash('Student Wallet has been updated.','flash',array('alert'=>'success'));
                    }
                    else
                    {
                        $this->Session->setFlash('Invalid Amount.','flash',array('alert'=>'danger'));
                    }
                }                
                return $this->redirect(array('action' => 'index'));
            }
            catch (Exception $e)
            {
                $this->Session->setFlash('Student record not found.','flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
        }        
    }
    public function trnhistory()
    {
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate1;
        $cond="";
        $cond=" 1=1 AND `UserGroup`.`user_id`=$this->luserId ";
        $this->Paginator->settings['conditions'] = array($this->Student->parseCriteria($this->Prg->parsedParams()),$cond);
        $this->Paginator->settings['joins'] = array(array('table'=>'wallets','alias'=>'Wallet','type'=>'Inner','conditions'=>array('Student.id=Wallet.student_id')),
                                                    array('table'=>'student_groups','type'=>'INNER','alias'=>'StudentGroup','conditions'=>array('Student.id=StudentGroup.student_id')),
                                                    array('table'=>'user_groups','type'=>'INNER','alias'=>'UserGroup','conditions'=>array('StudentGroup.group_id=UserGroup.group_id')));
        $this->Student->virtualFields = array('id' => 'Wallet.id','in_amount' => 'Wallet.in_amount','out_amount' => 'Wallet.out_amount','balance' => 'Wallet.balance',
                                              'date' => 'Wallet.date','type' => 'Wallet.type','remarks' => 'Wallet.remarks');
        $this->Paginator->settings['fields'] = array("email","Wallet.in_amount","Wallet.out_amount","Wallet.balance","Wallet.date","Wallet.type","Wallet.remarks");
        $this->Paginator->settings['order'] = array('id'=>'desc');
        $this->Paginator->settings['group'] = array('Wallet.id');
        $payment_type_arr=array("AD"=>"Administrator","PG"=>"Payment Gateway","EM"=>"Pay Exam");
        $this->set('payment_type_arr',$payment_type_arr);
        $this->set('Transactionhistory', $this->Paginator->paginate());
    }
}