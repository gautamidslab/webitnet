<?php
class AdminController extends AdminAppController
{
    public function beforeFilter()
    {
        parent::beforeFilter();
        $this->authenticate();
    }
}