<?php
class SubjectsController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator');
    public $components = array('Session','Paginator','search-master.Prg');
    public $presetVars = true;
    var $paginate = array('fields'=>array('Subject.id','Subject.subject_name','qbank_count'),
                          'joins'=>array(array('table'=>'questions','type'=>'LEFT','alias'=>'Question','conditions'=>array('Subject.id=Question.subject_id')),
                                         array('table'=>'subject_groups','type'=>'LEFT','alias'=>'SubjectGroup','conditions'=>array('Subject.id=SubjectGroup.subject_id')),
                                         array('table'=>'question_groups','type'=>'LEFT','alias'=>'QuestionGroup','conditions'=>array('Question.id=QuestionGroup.question_id')),
                                         array('table'=>'user_groups','type'=>'LEFT','alias'=>'UserGroup','conditions'=>array('SubjectGroup.group_id=UserGroup.group_id'))),
                          'limit'=>20,'maxLimit'=>500,'page'=>1,'order'=>array('Subject.subject_name'=>'asc'),'group'=>array('Subject.id'));
    public function index()
    {
        $this->Subject->UserWiseGroup($this->userGroupWiseId);
        $this->Prg->commonProcess();
        $this->Subject->virtualFields= array('qbank_count' => 'Count(DISTINCT(Question.id))');
        $this->Paginator->settings = $this->paginate;
        $cond="";
        $cond=" 1=1 AND `UserGroup`.`user_id`=$this->luserId";
        $this->Paginator->settings['conditions'] = array($this->Subject->parseCriteria($this->Prg->parsedParams()),$cond);
        $this->set('Subject', $this->Paginator->paginate());        
    }    
    public function add()
    {
        $this->loadModel('Group');
        $this->set('group_id', $this->Group->find('list',array('fields'=>array('id','group_name'),'conditions'=>array("Group.id IN($this->userGroupWiseId)"))));
        if ($this->request->is('post'))
        {
            try
            {
                if(is_array($this->request->data['SubjectGroup']['group_name']))
                {
                    $this->Subject->create();
                    if ($this->Subject->save($this->request->data))
                    {
                        $this->loadModel('SubjectGroup');
                        $this->request->data['SubjectGroup']['subject_id'] = $this->Subject->id;
                        if(is_array($this->request->data['SubjectGroup']['group_name']))
                        {
                            foreach($this->request->data['SubjectGroup']['group_name'] as $key => $value)
                            {
                                $this->SubjectGroup->create();
                                $this->request->data['SubjectGroup']['group_id']=$value;
                                $this->SubjectGroup->save($this->request->data);
                            }
                        }
                        $this->Session->setFlash('Your Subject has been saved.','flash',array('alert'=>'success'));
                        return $this->redirect(array('action' => 'add'));
                    }
                }
                else
                {
                    $this->Session->setFlash('Please Select atleast one group','flash',array('alert'=>'danger'));
                }
            }
            catch (Exception $e)
            {
                $this->Session->setFlash('Subject Name already exist.','flash',array('alert'=>'danger'));
            }
        }
    }
    public function edit($id = null)
    {
        $this->layout = null;
        if (!$id)
        {
            throw new NotFoundException(__('Invalid post'));
        }
        $this->Subject->UserWiseGroup($this->userGroupWiseId);
        $this->loadModel('Group');
        $this->set('group_id', $this->Group->find('list',array('fields'=>array('id','group_name'),'conditions'=>array("Group.id IN($this->userGroupWiseId)"))));
        $ids=explode(",",$id);
        $post=array();
        foreach($ids as $id)
        {
            $post[]=$this->Subject->findByid($id);
            $this->Subject->UserWiseGroup($this->userGroupWiseId);
        }
        $this->set('Subject',$post);
        if (!$post)
        {
            throw new NotFoundException(__('Invalid post'));
        }
        if ($this->request->is(array('post', 'put')))
        {
            $this->Subject->id = $id;
            try
            {
                foreach($this->data['Subject'] as $key => $value)
                {
                    if(!is_array($this->request->data['SubjectGroup'][$key]['group_name']))
                    {
                        $this->Session->setFlash('Please Select any group','flash',array('alert'=>'danger'));
                        return $this->redirect(array('action' => 'index'));
                    }
                    else
                    {
                        if ($this->Subject->save($this->request->data['Subject'][$key]))
                        {
                            if(is_array($this->request->data['SubjectGroup'][$key]['group_name']))
                            {
                                $this->loadModel('SubjectGroup');
                                $this->SubjectGroup->deleteAll(array('SubjectGroup.subject_id'=>$key,"SubjectGroup.group_id IN($this->userGroupWiseId)"));
                                foreach($this->request->data['SubjectGroup'][$key]['group_name'] as $key1 => $value1)
                                {
                                    $this->SubjectGroup->create();
                                    $this->request->data['SubjectGroup'][$key1]['subject_id']=$key;
                                    $this->request->data['SubjectGroup'][$key1]['group_id']=$value1;                            
                                    $this->SubjectGroup->save($this->request->data['SubjectGroup'][$key1]);
                                }
                            }
                            $this->Session->setFlash('Your Subject has been updated.','flash',array('alert'=>'success'));                        
                        }
                    }
                }
                return $this->redirect(array('action' => 'index'));
            }
            catch (Exception $e)
            {
                $this->Session->setFlash('Subject Name already exist.','flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
        }
        if (!$this->request->data)
        {
            $this->request->data = $post;
        }
    }    
    public function deleteall()
    {
        if ($this->request->is('post'))
        {
            try
            {
                $this->loadModel('SubjectGroup');
                $this->SubjectGroup->begin('SubjectGroup');
                foreach($this->data['Subject']['id'] as $key => $value)
                {
                    $this->SubjectGroup->deleteAll(array('SubjectGroup.subject_id'=>$value,"SubjectGroup.group_id IN($this->userGroupWiseId)"));
                }
                $this->Subject->query("DELETE `Subject` FROM `subjects` AS `Subject` LEFT JOIN `subject_groups` AS `SubjectGroup` ON `Subject`.`id` = `SubjectGroup`.`subject_id` WHERE `SubjectGroup`.`id` IS NULL");
                $this->SubjectGroup->commit();
                $this->Session->setFlash('Your Subject has been deleted.','flash',array('alert'=>'success'));
            }
            catch (Exception $e)
            {
                $this->SubjectGroup->rollback('SubjectGroup');
                $this->Session->setFlash('Delete exam first!','flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
        }        
        $this->redirect(array('action' => 'index'));
    }
}
