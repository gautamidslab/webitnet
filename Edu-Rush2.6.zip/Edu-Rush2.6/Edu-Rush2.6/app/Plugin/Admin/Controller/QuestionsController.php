<?php
class QuestionsController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Tinymce');
    public $components = array('Session','Paginator','search-master.Prg');
    public $presetVars = true;
    var $paginate = array('joins'=>array(
                                         array('table'=>'question_groups','type'=>'INNER','alias'=>'QuestionGroup','conditions'=>array('Question.id=QuestionGroup.question_id')),
                                         array('table'=>'user_groups','type'=>'INNER','alias'=>'UserGroup','conditions'=>array('QuestionGroup.group_id=UserGroup.group_id'))),                                         
                          'limit'=>20,'maxLimit'=>500,'page'=>1,'order'=>array('Question.id'=>'desc'),'group'=>array('Question.id'));
    public function index()
    {
        $this->Question->UserWiseGroup($this->userGroupWiseId);
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate;
        $cond="";
        $cond=" 1=1 AND `UserGroup`.`user_id`=$this->luserId ";
        $this->Paginator->settings['conditions'] = array($this->Question->parseCriteria($this->Prg->parsedParams()),$cond);
        $this->set('Question', $this->Paginator->paginate());
        
    }    
    public function add($id=null)
    {
        $this->loadModel('Qtype');
        $this->loadModel('Subject');
        $this->loadModel('Diff');
        $this->loadModel('Group');
        $this->set('qtype_id', $this->Qtype->find('list',array('fields'=>array('id','question_type'))));
        $this->set('subject_id', $this->Subject->find('list',array('fields'=>array('id','subject_name'),
                                                                   'joins'=>array(array('table'=>'subject_groups','type'=>'INNER','alias'=>'SubjectGroup','conditions'=>array('Subject.id=SubjectGroup.subject_id'))),
                                                                   'conditions'=>array("SubjectGroup.group_id IN($this->userGroupWiseId)"))));
        $this->set('diff_id', $this->Diff->find('list',array('fields'=>array('id','diff_level'))));
        $this->set('group_id', $this->Group->find('list',array('fields'=>array('id','group_name'),'conditions'=>array("Group.id IN($this->userGroupWiseId)"))));
        if($id==null)
        $selSubject=null;
        else
        $selSubject=$id;
        $this->set('selSubject',$selSubject);
        if ($this->request->is('post'))
        {
            $this->Question->create();
            try
            {
                if(is_array($this->request->data['Question']['answer']))
                $this->request->data['Question']['answer']=implode(",",$this->request->data['Question']['answer']);
                if($this->request->data['Question']['qtype_id']==1 && $this->request->data['Question']['answer']==null)
                {
                    $this->Session->setFlash('Please Check any answer!','flash',array('alert'=>'danger'));
                }
                elseif($this->request->data['Question']['qtype_id']==2 && $this->request->data['Question']['true_false']==null)
                {
                    $this->Session->setFlash('Please select true or false!','flash',array('alert'=>'danger'));
                }
                elseif($this->request->data['Question']['qtype_id']==3 && $this->request->data['Question']['fill_blank']==null)
                {
                    $this->Session->setFlash('Please fill blank space!','flash',array('alert'=>'danger'));
                }
                elseif(!is_array($this->request->data['QuestionGroup']['group_name']))
                {
                    $this->Session->setFlash('Please Select any group','flash',array('alert'=>'danger'));
                }
                else
                {
                    if ($this->Question->save($this->request->data))
                    {
                        $this->loadModel('QuestionGroup');
                        $this->request->data['QuestionGroup']['question_id'] = $this->Question->id;
                        if(is_array($this->request->data['QuestionGroup']['group_name']))
                        {
                            foreach($this->request->data['QuestionGroup']['group_name'] as $key => $value)
                            {
                                $this->QuestionGroup->create();
                                $this->request->data['QuestionGroup']['group_id']=$value;
                                $this->QuestionGroup->save($this->request->data);                        
                            }
                        }
                        $this->Session->setFlash('Your Question has been saved.','flash',array('alert'=>'success'));
                        return $this->redirect(array('action' => 'add'));
                    }
                }
            }
            catch (Exception $e)
            {
                $this->Session->setFlash('Question Error.','flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
        }
    }
    public function edit($id = null)
    {
        $this->Question->UserWiseGroup($this->userGroupWiseId);
        $this->loadModel('Qtype');
        $this->loadModel('Subject');
        $this->loadModel('Diff');
        $this->loadModel('Group');
        $this->set('qtype_id', $this->Qtype->find('list',array('fields'=>array('id','question_type'))));
        $this->set('subject_id', $this->Subject->find('list',array('fields'=>array('id','subject_name'),
                                                                   'joins'=>array(array('table'=>'subject_groups','type'=>'INNER','alias'=>'SubjectGroup','conditions'=>array('Subject.id=SubjectGroup.subject_id'))),
                                                                   'conditions'=>array("SubjectGroup.group_id IN($this->userGroupWiseId)"))));
        $this->set('diff_id', $this->Diff->find('list',array('fields'=>array('id','diff_level'))));
        $this->set('group_id', $this->Group->find('list',array('fields'=>array('id','group_name'),'conditions'=>array("Group.id IN($this->userGroupWiseId)"))));
        if (!$id)
        {
            throw new NotFoundException(__('Invalid post'));
        }
        $ids=explode(",",$id);
        $post=array();
        foreach($ids as $id)
        {
            $post[]=$this->Question->findById($id);
        }
        $this->set('Question',$post);
        if (!$post)
        {
            throw new NotFoundException(__('Invalid post'));
        }
        if ($this->request->is(array('post', 'put')))
        {
            $this->Question->id = $id;
            try
            {
                foreach($this->data['Question'] as $key => $value)
                {
                    if(is_array($this->request->data['Question'][$key]['answer']))
                    $this->request->data['Question'][$key]['answer']=implode(",",$this->request->data['Question'][$key]['answer']);
                    if($this->request->data['Question'][$key]['qtype_id']==1 && $this->request->data['Question'][$key]['answer']==null)
                    {
                        $this->Session->setFlash('Please Check any answer!','flash',array('alert'=>'danger'));
                    }
                    elseif($this->request->data['Question'][$key]['qtype_id']==2 && $this->request->data['Question'][$key]['true_false']==null)
                    {
                        $this->Session->setFlash('Please select true or false!','flash',array('alert'=>'danger'));
                    }
                    elseif($this->request->data['Question'][$key]['qtype_id']==3 && $this->request->data['Question'][$key]['fill_blank']==null)
                    {
                        $this->Session->setFlash('Please fill blank space!','flash',array('alert'=>'danger'));
                    }
                    elseif(!is_array($this->request->data['QuestionGroup'][$key]['group_name']))
                    {
                        $this->Session->setFlash('Please Select any group','flash',array('alert'=>'danger'));
                    }
                    else
                    {
                        if ($this->Question->save($this->request->data['Question'][$key]))
                        {
                            if(is_array($this->request->data['QuestionGroup'][$key]['group_name']))
                            {
                                $this->loadModel('QuestionGroup');
                                $this->QuestionGroup->deleteAll(array('QuestionGroup.question_id'=>$key,"QuestionGroup.group_id IN($this->userGroupWiseId)"));
                                foreach($this->request->data['QuestionGroup'][$key]['group_name'] as $key1 => $value1)
                                {
                                    $this->QuestionGroup->create();
                                    $this->request->data['QuestionGroup'][$key1]['question_id']=$key;
                                    $this->request->data['QuestionGroup'][$key1]['group_id']=$value1;                            
                                    $this->QuestionGroup->save($this->request->data['QuestionGroup'][$key1]);
                                }
                            }
                            $this->Session->setFlash('Your Question has been updated.','flash',array('alert'=>'success'));                        
                        }
                    }
                }
                return $this->redirect(array('action' => 'index'));
            }
            catch (Exception $e)
            {
                $this->Session->setFlash('Question Error.','flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
        }
        if (!$this->request->data)
        {
            $this->request->data = $post;
        }
    }    
    public function deleteall()
    {
        if ($this->request->is('post'))
        {
            try
            {
                $this->loadModel('QuestionGroup');
                $this->QuestionGroup->begin('QuestionGroup');
                foreach($this->data['Question']['id'] as $key => $value)
                {
                    $this->QuestionGroup->deleteAll(array('QuestionGroup.question_id'=>$value,"QuestionGroup.group_id IN($this->userGroupWiseId)"));
                }
                $this->Question->query("DELETE `Question` FROM `questions` AS `Question` LEFT JOIN `question_groups` AS `QuestionGroup` ON `Question`.`id` = `QuestionGroup`.`question_id` WHERE `QuestionGroup`.`id` IS NULL");
                $this->QuestionGroup->commit();
                $this->Session->setFlash('Your Question has been deleted.','flash',array('alert'=>'success'));
            }
            catch (Exception $e)
            {
                $this->QuestionGroup->rollback('QuestionGroup');
                $this->Session->setFlash('Delete exam first!','flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
        }        
        $this->redirect(array('action' => 'index'));
    }
    public function viewquestion($id = null)
    {
        $this->layout=null;
        if (!$id)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        $this->set('id',$id);
    }
    public function view($id = null)
    {
        $this->layout='script';
        if (!$id)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        $post = $this->Question->findById($id);
        $this->set('post',$post);
    }
}
