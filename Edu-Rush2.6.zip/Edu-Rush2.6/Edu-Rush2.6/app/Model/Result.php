<?php
class Result extends AppModel
{
  public $useTable="exam_results";  
  public $belongsTo=array('Exam'=>array('className'=>'exams',
                                        'order'=>array('Result.start_time'=>'desc')));
  public function userSubject($id)
  {
    $ExamStat=ClassRegistry::init('ExamStat');
    $userSubject=$ExamStat->find('all',array('fields'=>array('DISTINCT(Subject.id)','Subject.subject_name'),
                                'joins'=>array(array('table'=>'questions','alias'=>'Question','type'=>'Inner',
                                                     'conditions'=>array('ExamStat.question_id=Question.id')),
                                               array('table'=>'subjects','alias'=>'Subject','type'=>'Inner',
                                                     'conditions'=>array('Question.subject_id=Subject.id'))),
                                'conditions'=>array('ExamStat.exam_result_id'=>$id)));
    return$userSubject;
  }
  public function userSubjectMarks($id,$subjectId,$sumField)
  {
    $ExamStat=ClassRegistry::init('ExamStat');
    $ExamStat->virtualFields=array('total_marks'=>"SUM(ExamStat.$sumField)");
    $userSubject=$ExamStat->find('first',array('fields'=>array('total_marks'),
                                'joins'=>array(array('table'=>'questions','alias'=>'Question','type'=>'Inner',
                                                     'conditions'=>array('ExamStat.question_id=Question.id')),
                                               array('table'=>'subjects','alias'=>'Subject','type'=>'Inner',
                                                     'conditions'=>array('Question.subject_id=Subject.id'))),
                                'conditions'=>array('ExamStat.exam_result_id'=>$id,'Subject.id'=>$subjectId)));
    $userSubjectMarks=$userSubject['ExamStat']['total_marks'];
    return$userSubjectMarks;
  }
  public function userSubjectQuestion($id,$subjectId)
  {
    $ExamStat=ClassRegistry::init('ExamStat');
    $userSubjectQuestion=$ExamStat->find('count',array('joins'=>array(array('table'=>'questions','alias'=>'Question','type'=>'Inner',
                                                     'conditions'=>array('ExamStat.question_id=Question.id')),
                                               array('table'=>'subjects','alias'=>'Subject','type'=>'Inner',
                                                     'conditions'=>array('Question.subject_id=Subject.id'))),
                                'conditions'=>array('ExamStat.exam_result_id'=>$id,'Subject.id'=>$subjectId)));
    return$userSubjectQuestion;
  }
  public function userMarks($id)
  {
    $ExamStat=ClassRegistry::init('ExamStat');
    $ExamStat->virtualFields=array('total_marks'=>"SUM(ExamStat.marks)");
    $userSubject=$ExamStat->find('first',array('fields'=>array('total_marks'),
                                'conditions'=>array('ExamStat.exam_result_id'=>$id)));
    $userSubjectMarks=$userSubject['ExamStat']['total_marks'];
    return$userSubjectMarks;
  }
  public function userSubjectTime($id,$subjectId)
  {
    $ExamStat=ClassRegistry::init('ExamStat');
    $userSubject=$ExamStat->find('first',array('fields'=>array('SUM(`ExamStat`.`modified`-`ExamStat`.`attempt_time`) as time_taken'),
                                'joins'=>array(array('table'=>'questions','alias'=>'Question','type'=>'Inner',
                                                     'conditions'=>array('ExamStat.question_id=Question.id')),
                                               array('table'=>'subjects','alias'=>'Subject','type'=>'Inner',
                                                     'conditions'=>array('Question.subject_id=Subject.id'))),
                                'conditions'=>array('ExamStat.exam_result_id'=>$id,'Subject.id'=>$subjectId)));
    $userSubjectTime=$userSubject[0]['time_taken'];
    return$userSubjectTime;
  }
  public function userMarksheet($id)
  {
    $userSubject=$this->userSubject($id);
    $userMarksheet=array();
    $grandTotalMarks=0;$grandObtainedMarks=0;$grandTotalQuestion=0;$grandTimeTaken=0;
    foreach($userSubject as $k=>$subjectValue)
    {
        $totalMarks=$this->userSubjectMarks($id,$subjectValue['Subject']['id'],'marks');
        $obtainedMarks=$this->userSubjectMarks($id,$subjectValue['Subject']['id'],'marks_obtained');
        $totalQuestion=$this->userSubjectQuestion($id,$subjectValue['Subject']['id']);
        $allMarks=$this->userMarks($id);
        $timeTaken=$this->userSubjectTime($id,$subjectValue['Subject']['id']);
        $marksWeightage=CakeNumber::precision(($totalMarks*100)/$allMarks,2);
        $grandTotalMarks=$grandTotalMarks+$totalMarks;
        $grandObtainedMarks=$grandObtainedMarks+$obtainedMarks;
        $grandTotalQuestion=$grandTotalQuestion+$totalQuestion;
        $grandTimeTaken=$grandTimeTaken+$timeTaken;
        $percent=CakeNumber::precision(($obtainedMarks*100)/$totalMarks,2);
        $userMarksheet[$k]['Subject']['name']=$subjectValue['Subject']['subject_name'];
        $userMarksheet[$k]['Subject']['total_marks']=$totalMarks;
        $userMarksheet[$k]['Subject']['obtained_marks']=$obtainedMarks;
        $userMarksheet[$k]['Subject']['percent']=$percent;
        $userMarksheet[$k]['Subject']['total_question']=$totalQuestion;
        $userMarksheet[$k]['Subject']['marks_weightage']=$marksWeightage;
        $userMarksheet[$k]['Subject']['time_taken']=$timeTaken;
    }
    if($grandTotalMarks==0)
    $grandPercent=0;
    else
    $grandPercent=$percent=CakeNumber::precision(($grandObtainedMarks*100)/$grandTotalMarks,2);
    $userMarksheet['total']['Subject']=array('name'=>'Grand Total','total_marks'=>$grandTotalMarks,'obtained_marks'=>$grandObtainedMarks,
                                             'percent'=>$grandPercent,'total_question'=>$grandTotalQuestion,'marks_weightage'=>100,'time_taken'=>$grandTimeTaken);
    return$userMarksheet;
  }  
}
?>