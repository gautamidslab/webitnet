<?php
class Transactionhistory extends AppModel
{
  public $useTable="wallets";  
}
?>