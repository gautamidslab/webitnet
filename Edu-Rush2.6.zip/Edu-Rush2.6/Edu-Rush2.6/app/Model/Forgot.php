<?php
class Forgot extends AppModel
{
  public $useTable="students";
}
?>