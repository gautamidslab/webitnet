Mathslate Plugin for TinyMCE4
=================

Tinymcefour plugin for constructing mathematical expressions

Install this directory in tinymce/js/tinymce/plugins/mathslate. All
files are licensed under GPL 3 which is include.  Mathslate files are
copyright 2014 Daniel Thies <dthies@ccal.edu>

