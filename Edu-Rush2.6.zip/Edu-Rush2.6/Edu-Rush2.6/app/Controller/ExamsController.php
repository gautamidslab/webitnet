<?php
App::uses('CakeTime', 'Utility');
App::uses('CakeEmail', 'Network/Email');
class ExamsController extends AppController
{
    public $helpers = array('Html');
    public $currentDateTime,$studentId;
    public $components = array('CustomFunction');
    public function beforeFilter()
    {
        parent::beforeFilter();
        $this->authenticate();
        $this->currentDateTime=CakeTime::format('Y-m-d H:i:s',CakeTime::convert(time(),$this->siteTimezone));
        $this->studentId=$this->userValue['Student']['id'];        
    }
    public function index()
    {
        $todayExam=$this->Exam->getUserExam("today",$this->studentId,$this->currentDateTime);
        $upcomingExam=$this->Exam->getUserExam("upcoming",$this->studentId,$this->currentDateTime);
        $this->set('upcomingExam',$upcomingExam);
        $this->set('todayExam',$todayExam);
    }
    public function today()
    {
        $todayExam=$this->Exam->getUserExam("today",$this->studentId,$this->currentDateTime);
        $this->set('todayExam',$todayExam);
    }
    public function upcoming()
    {
        $upcomingExam=$this->Exam->getUserExam("upcoming",$this->studentId,$this->currentDateTime);
        $this->set('upcomingExam',$upcomingExam);
    }    
    public function view($id)
    {
        $this->layout=null;
        $this->loadModel('ExamQuestion');
        $this->loadModel('ExamGroup');
        if (!$id)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        $checkPost=$this->Exam->checkPost($id,$this->studentId);
        if($checkPost==0)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'error'));
        }
        $post = $this->Exam->findByIdAndStatus($id,'Active');
        if (!$post)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'error'));
        }
        if($post['Exam']['type']=="Exam")
        {
            $subjectDetail=$this->Exam->getSubject($id);
            $totalQuestion=$this->ExamQuestion->find('count',array('conditions'=>array("exam_id=$id")));
            $totalMarks=$this->Exam->totalMarks($id);
        }
        else
        {
            $subjectDetail=$this->Exam->getPrepSubject($id);
            $totalQuestion=$this->Exam->totalPrepQuestions($id);
            $totalMarks=0;
        }
        $this->set('post', $post);
        $this->set('subjectDetail', $subjectDetail);
        $this->set('totalQuestion', $totalQuestion);
        $this->set('totalMarks', $totalMarks);        
    }
    public function instruction($id)
    {
        $this->layout='exam';
        $this->loadModel('ExamQuestion');
        if (!$id)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        $checkPost=$this->Exam->checkPost($id,$this->studentId);
        if($checkPost==0)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'error'));
        }
        $post = $this->Exam->findByIdAndStatus($id,'Active');
        if (!$post)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'error'));
        }
        $ispaid=false;
        $paidexam=$post['Exam']['paid_exam'];
        $this->loadModel('ExamResult');
        $this->loadModel('ExamOrder');
        $totalExam=$this->ExamResult->find('count',array('conditions'=>array('exam_id'=>$id,'student_id'=>$this->studentId)));
        $attempt_count=$post['Exam']['attempt_count'];
        if($paidexam==1)
        {
            $countExamOrder=$this->ExamOrder->find('count',array('conditions'=>array('exam_id'=>$id,'student_id'=>$this->studentId)));
            if($countExamOrder*$attempt_count>$totalExam)
            {
                $ispaid=true;
            }
        }
        $this->set('post', $post);
        $this->set('ispaid', $ispaid);
    }
    public function error()
    {
        $this->layout=null;
    }
    public function start($id=null,$quesNo=null)
    {
        $this->layout='exam';
        if($id==null)
        $id=0;        
        $checkPost=$this->Exam->checkPost($id,$this->studentId);
        if($checkPost==0)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        $this->loadModel('ExamResult');
        $this->loadModel('ExamOrder');
        $post = $this->Exam->findById($id);
        $currentExamResult=$this->ExamResult->find('count',array('conditions'=>array('student_id'=>$this->studentId,'end_time'=>null)));
        if($currentExamResult==0)
        {
            $paidexam=$post['Exam']['paid_exam'];
            $totalExam=$this->ExamResult->find('count',array('conditions'=>array('exam_id'=>$id,'student_id'=>$this->studentId)));
            $attempt_count=$post['Exam']['attempt_count'];
            if($paidexam==1)
            {
                $countExamOrder=$this->ExamOrder->find('count',array('conditions'=>array('exam_id'=>$id,'student_id'=>$this->studentId)));
                if($countExamOrder*$attempt_count<=$totalExam && $attempt_count>0)
                {
                    $this->redirect(array('action' => 'paid',$id,'P'));
                }                
            }
            else
            {
                if($attempt_count<=$totalExam && $attempt_count>0)
                {
                    $this->Session->setFlash('You have attempted maximum exam.','flash',array('alert'=>'danger'));
                    $this->redirect(array('action' => 'index'));
                }
            }
            $this->Exam->userExamInsert($id,$post['Exam']['ques_random'],$post['Exam']['type'],$this->studentId,$this->currentDateTime);
        }
        $examWise=$this->ExamResult->find('first',array('conditions'=>array('student_id'=>$this->studentId,'end_time'=>null)));
        if($quesNo==null)
        {
            if($currentExamResult==1)
            {
                $this->loadModel('ExamStat');
                $examStat=$this->ExamStat->find('first',array('fields'=>array('ques_no'),'conditions'=>array('exam_result_id'=>$examWise['ExamResult']['id'],'attempt_time'=>NULL)));
                if($examStat && $examStat['ExamStat']['ques_no']!=1)
                $quesNo=$examStat['ExamStat']['ques_no']-1;
                else
                $quesNo=1;
            }
            else
            $quesNo=1;
        }
        if($currentExamResult==1)
        {
            $examWiseId=$examWise['ExamResult']['exam_id'];
            $endTime=CakeTime::format('Y-m-d H:i:s',CakeTime::fromString($examWise['ExamResult']['start_time'])+($post['Exam']['duration']*60));
            if($this->currentDateTime>=$endTime && $post['Exam']['duration']>0)
            $this->redirect(array('action' =>'finish',$examWiseId));
            if($examWiseId!=$id)
            $this->redirect(array('action' =>'start',$examWiseId,$quesNo));
        }
        $this->loadModel('ExamQuestion');
        $userExamQuestion=$this->Exam->userExamQuestion($id,$this->studentId,$quesNo);
        $examResult = $this->ExamResult->find('first',array('conditions'=>array('exam_id'=>$id,'student_id'=>$this->studentId,'end_time'=>null)));
        $userSectionQuestion=$this->Exam->userSectionQuestion($id,$post['Exam']['type'],$this->studentId);
        if($post['Exam']['type']=="Exam")
        $totalQuestion=$this->ExamQuestion->find('count',array('conditions'=>array('exam_id'=>$id)));
        else
        $totalQuestion=$this->Exam->totalPrepQuestions($id,$this->studentId);
        $nquesNo=$quesNo;
        $pquesNo=$quesNo;
        
        if($totalQuestion<$quesNo)
        $quesNo=1;
        $currSubjectName=$this->Exam->userSubject($id,$quesNo,$this->studentId);
        $this->Exam->userQuestionRead($id,$quesNo,$this->studentId,$this->currentDateTime);
        $oquesNo=$quesNo;
        if($totalQuestion==$quesNo)
        $quesNo=0;
        if($totalQuestion<$quesNo)
        $pquesNo=2;
        if($quesNo==1)
        $pquesNo=2;        
        $this->set('userExamQuestion',$userExamQuestion);
        $this->set('userSectionQuestion',$userSectionQuestion);
        $this->set('currSubjectName',$currSubjectName);
        $this->set('post',$post);
        $this->set('examResult',$examResult);
        $this->set('siteTimezone',$this->siteTimezone);
        $this->set('examId',$id);
        $this->set('nquesNo',$quesNo+1);
        $this->set('pquesNo',$pquesNo-1);
        $this->set('oquesNo',$oquesNo);
        $this->set('totalQuestion',$totalQuestion);
        $this->set('examResultId',$userExamQuestion['ExamStat']['exam_result_id']);
    }
    function save($id=null,$quesNo=null)
    {
        $this->Exam->userSaveAnswer($id,$quesNo,$this->studentId,$this->currentDateTime,$this->request->data);
        if($this->request->data['saveNext']=="Yes")
        $quesNo++;
        $this->redirect(array('action' => "start/$id/$quesNo"));
    }
    function resetAnswer($id=null,$quesNo=null)
    {
        $this->Exam->userResetAnswer($id,$quesNo,$this->studentId);
        $this->redirect(array('action' => "start/$id/$quesNo"));
    }
    function reviewAnswer($id=null,$quesNo=null)
    {
        $this->Exam->userReviewAnswer($id,$quesNo,$this->studentId,1);
        $quesNo++;
        $this->redirect(array('action' => "start/$id/$quesNo"));
    }
    function unreviewAnswer($id=null,$quesNo=null)
    {
        $this->Exam->userReviewAnswer($id,$quesNo,$this->studentId,0);
        $quesNo++;
        $this->redirect(array('action' => "start/$id/$quesNo"));
    }
    function finish($id=null,$warn=null)
    {
        if($id==null)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        $this->loadModel('ExamResult');
        $currentExamResult=$this->ExamResult->find('first',array('conditions'=>array('exam_id'=>$id,'student_id'=>$this->studentId,'end_time'=>null)));
        if($currentExamResult)
        {
            $this->Exam->userExamFinish($id,$this->studentId,$this->currentDateTime);
            if($warn==null)
            $this->redirect(array('controller'=>'Exams','action' => 'feedbacks',$currentExamResult['ExamResult']['id']));
            else
            $this->redirect(array('controller'=>'Ajaxcontents','action' => 'examclose',$currentExamResult['ExamResult']['id']));
        }
        else
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
    }
    function paid($id=null,$type=null)
    {
        if($id==null)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        else
        {
            $this->loadModel('ExamOrder');
            $countExamOrder=$this->ExamOrder->find('count',array('conditions'=>array('exam_id'=>$id,'student_id'=>$this->studentId)));
            if($countExamOrder>=1 && $type==null)
            {
                $this->redirect(array('action' => 'start',$id));
            }
            else
            {
                $exampost=$this->Exam->findByIdAndPaidExam($id,'1');
                $amount=$exampost['Exam']['amount'];
                $balance=$this->CustomFunction->WalletBalance($this->studentId);
                if($balance>=$amount)
                {
                    if($this->CustomFunction->WalletInsert($this->studentId,$amount,"Deducted",$this->currentDateTime,"EM","$amount Deducted for paying exam"))
                    {
                        $this->ExamOrder->create();
                        $this->ExamOrder->save(array("student_id"=>$this->studentId,"exam_id"=>$id));
                        $this->redirect(array('action' => 'start',$id));
                    }
                }
                else
                {
                    $this->Session->setFlash('Insufficient Amount.','flash',array('alert'=>'danger'));
                    $this->redirect(array('action' => 'index'));
                }
            }
        }
        $this->redirect(array('action' => 'index'));
    }
    public function submit($examId=null,$examResultId=null)
    {
        $this->layout=null;
        $this->loadModel('ExamStat');
        $this->set('examId',$examId);
        $this->set('post',$this->Exam->findById($examId));
        $this->set('attempted',$this->ExamStat->find('count',array('conditions'=>array('ExamStat.exam_result_id'=>$examResultId,'opened'=>1))));
        $this->set('notAttempted',$this->ExamStat->find('count',array('conditions'=>array('ExamStat.exam_result_id'=>$examResultId,'opened'=>0))));
        $this->set('answered',$this->ExamStat->find('count',array('conditions'=>array('ExamStat.exam_result_id'=>$examResultId,'answered'=>1))));
        $this->set('notAnswered',$this->ExamStat->find('count',array('conditions'=>array('ExamStat.exam_result_id'=>$examResultId,'answered'=>0))));
        $this->set('review',$this->ExamStat->find('count',array('conditions'=>array('ExamStat.exam_result_id'=>$examResultId,'review'=>1))));
    }
    public function guidelines($id=null)
    {
        $this->layout='exam';
        if (!$id)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        $checkPost=$this->Exam->checkPost($id,$this->studentId);
        if($checkPost==0)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'error'));
        }
        $post = $this->Exam->findByIdAndStatus($id,'Active');
        if (!$post)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'error'));
        }
        $this->set('post',$post);
    }
    public function feedbacks($id)
    {
        $this->layout='exam';
        if (!$id)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'index'));
        }
        $this->loadModel('ExamResult');
        $examArr=$this->ExamResult->findByIdAndStudentId($id,$this->studentId);
        if (!$examArr)
        {
            $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
            $this->redirect(array('action' => 'error'));
        }
        $this->set('id',$id);
        $this->set('isClose','No');
        if ($this->request->is('post'))
        {
            try
            {
                $this->loadModel('ExamFeedback');
                $this->ExamFeedback->create();
                $comments="1. The test instructions were ".$this->request->data['Exam']['test_instruction']."<br><br>
                2. Language of question was ".$this->request->data['Exam']['question_language']."<br><br>
                3. Overall test experience was ".$this->request->data['Exam']['test_experience']."<br><br>
                Any other feedback suggestion: ".$this->request->data['Exam']['comments'];
                $recordArr=array('ExamFeedback'=>array('exam_result_id'=>$id,'comments'=>$comments));
                $this->ExamFeedback->save($recordArr);
                $this->Session->setFlash('Your Feedback has submitted successfully send!','flash',array('alert'=>'success'));
                $this->set('isClose','Yes');
            }
            catch (Exception $e)
            {
                $this->Session->setFlash('Your Feedback already submitted.','flash',array('alert'=>'danger'));
                $this->set('isClose','Yes');
            }            
        }       
    }
}
