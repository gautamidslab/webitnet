<?php
App::uses('CakeTime', 'Utility');
class AjaxcontentsController extends AppController
{
    public function beforeFilter()
    {
        parent::beforeFilter();
        $this->authenticate();
    }
    public function examwarning($id)
    {
        $this->layout=null;
        $this->loadModel('ExamWarn');
        $navigateCount=$this->ExamWarn->find('count',array('conditions'=>array('exam_result_id'=>$id)));
        $navigateCount++;
        if($navigateCount>=4)
        {
            print "Yes";
            exit(0);
        }
        else
        {
            $recordArr=array('ExamWarn'=>array('exam_result_id'=>$id));
            $this->ExamWarn->create();
            $this->ExamWarn->save($recordArr);
        }
    }
    public function examclose($id)
    {
        $this->layout='exam';
        $this->set('UserArr',$this->userValue);
        $this->set('id',$id);
    }
}
