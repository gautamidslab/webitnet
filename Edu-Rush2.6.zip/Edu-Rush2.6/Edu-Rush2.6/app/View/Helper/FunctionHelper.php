<?php
/**
 * Application level View Helper
 *
 * This file is application-wide helper file. You can put all
 * application-wide helper-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.View.Helper
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Helper', 'View');
App::uses('CakeTime', 'Utility');

/**
 * Application helper
 *
 * Add your application-wide methods in the class below, your helpers
 * will inherit them.
 *
 * @package       app.View.Helper
 */
class FunctionHelper extends Helper
{
    var $helpers = array('Html');
    public function secondsToWords($seconds)
    {
        $ret = "";
        if($seconds>0)
        {
            /*** get the hours ***/
            $hours = intval(intval($seconds) / 3600);
            if($hours > 0)
            {
                $ret .= "$hours Hours ";
            }
            /*** get the minutes ***/
            $minutes = bcmod((intval($seconds) / 60),60);
            if($hours > 0 || $minutes > 0)
            {
                $ret .= "$minutes Mins. ";
            }
            if(strlen($ret)==0)
            {
                $ret .= "$seconds Sec ";
            }
        }
        else
        {
            $ret="Unlimited";
        }
        return $ret;
    }
    public function showGroupName($gropArr,$string=" | ")
    {
        $groupNameArr=array();
        foreach($gropArr as $groupName)
        {
            $groupNameArr[]=$groupName['group_name'];
        }
        unset($groupName);
        $showGroup= implode($string,$groupNameArr);
        unset($groupNameArr);
        return $showGroup;
    }
    public function showExamType($post)
    {
        if($post['type']=="Exam")
        {
            $showExam="<strong>".$post['total_marks']."</strong> Marks";
        }
        else
        {
            $showExam="<strong>".$post['total_question']."</strong> Questions";
        }
        return$showExam;
    }
    public function showExamList($exam,$currency,$dateFormat,$isAttempt=false)
    {
        $examList="";$attempt="";
        foreach($exam as $post)
        {
            $id=$post['Exam']['id'];
            $viewUrl=$this->Html->url(array('controller'=>'Exams','action'=>"view/$id"));
            $instructionUrl=$this->Html->url(array('controller'=>'Exams','action'=>"instruction/$id"));
            if($post['Exam']['paid_exam']=="1"){$amount="<td>$currency". $post['Exam']['amount']."</td>";}else{$amount="<td>&nbsp;</td>";}
            if($isAttempt==true){$attempt="<td>". $this->Html->link('<span class="fa fa-book"></span>&nbsp; Attempt Now',array('controller'=>'Exams','action'=>'guidelines',$id),array('escape'=>false,'target'=>'_blank','class'=>'btn btn-success'))."</td>";}
            $examList.="<tr>
                            <td>". h($post['Exam']['name'])."</td>
                            <td>". h($post['Exam']['type'])."</td>
                            <td>". $this->showExamType($post['Exam'])."</td>
                            <td>".CakeTime::format($dateFormat,$post['Exam']['start_date'])."</td>".
                            $amount."
                            <td>". $this->Html->link('<span class="glyphicon glyphicon-fullscreen"></span>&nbsp; View Details','#',array('onclick'=>"show_modal('$viewUrl');",'escape'=>false,'class'=>'btn btn-info'))."</td>".
                            $attempt."
                        </tr>";
        }
        unset($post);unset($id);
        return$examList;
    }
    
}
